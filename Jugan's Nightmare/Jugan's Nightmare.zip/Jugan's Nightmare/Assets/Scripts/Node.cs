﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Node : MonoBehaviour {
    public int attack;
    public int health;
    public int shield;
    public int team = 0; //0 = neutral, 1 = blue, 2 = red.
    public bool mainbase = false;
    public Transform f1, f2, b1, b2;
    public List<Transform> allUnits = new List<Transform>();

    public void addUnit(int t, Transform s)
    {
        if(t == team)
        {
            allUnits.Add(s);
        }else if(t == 0)
        {
            allUnits.Add(s);
            team = t;
        }
        updateMan();
    }
    public void updateMan()
    {
        attack = 0;
        health = 0;
        shield = 0;
        foreach(Transform s in allUnits)
        {
            Unit k = s.parent.GetComponent<Unit>();
            attack += k.getAttributes()[0];
            health += k.getAttributes()[1];
            shield += k.getAttributes()[2];
        }
    }
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
