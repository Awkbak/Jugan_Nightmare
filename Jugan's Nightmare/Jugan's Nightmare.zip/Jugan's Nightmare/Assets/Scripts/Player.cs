﻿using UnityEngine;
using System.Collections.Generic;

public class Player : MonoBehaviour {
    public List<Transform> allNodes = new List<Transform>();
    public Transform environment;
    public Transform mainBase;
    public Transform dan0;
    public Transform dan1;
    public Transform dan2;
    public int available;

	// Use this for initialization
	void Start () {
        mainBase = environment.GetComponent<Game_Environment>().blueBase;
        available = 3;
    }
	
	// Update is called once per frame
	void Update () {
	}

    void move()
    {

    }

    void attack()
    {

    }

    public void assign(int ID) //LADIES AND GENTLEMEN, STEP RIGHT UP, CHOOSE YOUR UNITS. 0 for Balance, 1 for Offense, and last but NOT least, 2 for defense!
    {
        int x = mainBase.GetComponent<Node>().allUnits.Count;
        if (available > 0)
        {
            if (ID == 0)
            {
                GameObject unit = Instantiate(dan0, new Vector3(mainBase.position.x, 0.1f + 0.1f * x, mainBase.position.z), mainBase.rotation) as GameObject;
                unit.transform.SetParent(mainBase);
                mainBase.GetComponent<Node>().allUnits.Add(unit.transform);
            }
            else if (ID == 1)
            {
                GameObject unit = Instantiate(dan1, new Vector3(mainBase.position.x, 0.1f + 0.1f * x, mainBase.position.z), mainBase.rotation) as GameObject;
                unit.transform.SetParent(mainBase);
                mainBase.GetComponent<Node>().allUnits.Add(unit.transform);
            }
            else
            {
                GameObject unit = Instantiate(dan2, new Vector3(mainBase.position.x, 0.1f + 0.1f * x, mainBase.position.z), mainBase.rotation) as GameObject;
                unit.transform.SetParent(mainBase);
                mainBase.GetComponent<Node>().allUnits.Add(unit.transform);
            }
            available -= 1;
        }
    }
}

    